import Header from "../components/Header";

function About() {
  return (
    <>
      <Header />
      <h1>About Page</h1>
    </>
  );
}

export default About;
