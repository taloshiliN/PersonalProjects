import Header from "../components/Header";

function Events() {
  return (
    <>
      <Header />
      <h1>Event Page</h1>
    </>
  );
}

export default Events;
